package com.example.helloworld;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity {
    Button ButtonClick;
    TextView TextName;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ButtonClick = findViewById(R.id.buttonClick);
        TextName = findViewById(R.id.TextName);

        ButtonClick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                TextName.setText("Welcome!");
            }
        });
    }
}